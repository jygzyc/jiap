package com.poc.targetapp;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PoCActivity extends Activity {

    private static final String TAG = "PoC";
    private TextView tvLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poc);

        tvLog = findViewById(R.id.tv_log);
        LinearLayout llButtons = findViewById(R.id.ll_buttons);

        for (Class<? extends Exploit> exploit : ExploitRegistry.EXPLOITS) {
            Button btn = new Button(this);
            btn.setText(exploit.getSimpleName().replace("Exploit", ""));
            btn.setOnClickListener(v -> runExploit(exploit));
            llButtons.addView(btn);
        }
    }

    private void runExploit(Class<? extends Exploit> clazz) {
        log("─── " + clazz.getSimpleName() + " ───");
        try {
            Exploit exploit = clazz.getConstructor(Context.class).newInstance(this);
            exploit.execute();
            log("Done");
        } catch (Exception e) {
            log("ERROR: " + e.getMessage());
            Log.e(TAG, "Exploit failed", e);
        }
    }

    private void log(String msg) {
        Log.i(TAG, msg);
        runOnUiThread(() -> {
            tvLog.append(msg + "\n");
            ((ScrollView) tvLog.getParent()).fullScroll(View.FOCUS_DOWN);
        });
    }
}
